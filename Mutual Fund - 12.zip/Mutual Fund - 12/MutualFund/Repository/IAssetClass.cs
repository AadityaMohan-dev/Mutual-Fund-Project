﻿using MutualFund.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Repository
{
    public interface IAssetClass
    {
        Task<List<AssetClassesModel>> GetAllAssetClasses();
        Task<List<AssetClassesModel>> GetAssetClassByID(int asset_ID);
        Task<AssetClassesModel> CreateAssetClass(AssetClassesModel assetClassesModel);
        Task<AssetClassesModel> UpdateAssetClass(int asset_ID, AssetClassesModel assetClassesModel);
        Task<AssetClassesModel> DeleteAssetClass(int asset_ID);
    }
}
