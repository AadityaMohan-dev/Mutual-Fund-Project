﻿using FutureCapitals.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FutureCapitals.DataAccessLayer
{
    public interface Iusm
    {
        Task<List<usmModel>> GetSecurities();
        Task<List<usmModel>> GetByISIN(string isin);
        Task<List<usmModel>> GetBySymbol(string symbol);

        Task<usmModel> CREATENSE(usmModel nSE_data1);
        Task<usmModel> UPDATENSE(string symbol,usmModel nSE_data1);
        Task<usmModel> DELETENSE(string symbol);


    }
}
