﻿using MutualFund.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.DI
{
    public interface IViewTheme
    {
        Task<List<ViewThemeModel>> GetAllThemes();
        Task<List<ViewThemeModel>> GetThemeDescending();
        Task<List<ViewThemeModel>>GetThemesByThemeID(int theme_Id);
        Task<ViewThemeModel> CreateTheme(ViewThemeModel themesModel);
        Task<ViewThemeModel> UpdateTheme(int theme_Id, ViewThemeModel themesModel);
        Task<ViewThemeModel> DeleteTheme(int theme_Id);

    }
}
