﻿//using MutualFund.Model;
using MutualFund.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Repository
{
    public interface IPortfolioComposition
    {
        Task<List<PortfolioCompositionModel>> GetAllPortfolios();
        Task<List<PortfolioCompositionModel>> GetPortfolioByID(int portfolio_Composition_ID);
        Task<PortfolioCompositionModel> Createportfolio(PortfolioCompositionModel portfolioCompositionModel);
        Task<PortfolioCompositionModel> UpdatePortfolio(int portfolio_Composition_ID, PortfolioCompositionModel portfolioCompositionModel);
        Task<PortfolioCompositionModel> DeletePortfolio(int portfolio_ID);
        Task<List<PortfolioCompositionModel>> GetByCompID(int portfolio_Composition_ID);
    }
}
