﻿using MutualFund.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Repository
{
    public interface IAllocations
    {
        Task<List<AllocationsModel>> GetAllAllocations();
        Task<List<AllocationsModel>> GetAllocationsByID(int allocation_Id);
        Task<List<AllocationsModel>> GetAllocationsByThemeID(int theme_Id);
        Task<AllocationsModel> CreateAllocations(AllocationsModel allocationsModel);
        Task<AllocationsModel> UpdateAllocations(int allocation_ID, AllocationsModel allocationsModel);
        Task<AllocationsModel> UpdateAllocationByThemeID(int theme_ID, int Asset_ID, AllocationsModel allocationsModel);
        Task<AllocationsModel> DeleteAllocations(int allocation_ID);
        public double SUMByTheme(int themeID);

    }
}
