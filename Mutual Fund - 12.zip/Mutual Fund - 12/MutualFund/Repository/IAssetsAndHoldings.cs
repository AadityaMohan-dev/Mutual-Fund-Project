﻿using MutualFund.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.DI
{
    public interface IAssets
    {
        Task<List<AssetsAndHoldingsModel>> GetAllAssets();
        Task<List<AssetsAndHoldingsModel>> GetAssetsByName(string security_Name);

        Task<AssetsAndHoldingsModel> CreateAsset(AssetsAndHoldingsModel assetsModels);
        Task<AssetsAndHoldingsModel> UpdateAsset(string security_Name, AssetsAndHoldingsModel assetsModels);
        Task<AssetsAndHoldingsModel> DeleteAsset(string security_Name);
        //Task<double> Total_Value(double price, int quantity);
    }
}
