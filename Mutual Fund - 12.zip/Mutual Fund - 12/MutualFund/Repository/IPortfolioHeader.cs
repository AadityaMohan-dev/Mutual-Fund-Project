﻿using MutualFund.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.DI
{
    public interface IPortfolioHeader
    {
        Task<List<PortfolioHeaderModel>> GetAllPortfolioHeader();
        Task<List<PortfolioHeaderModel>> GetPortfolioHeaderByName(string portfolio_Name);
        //Task<List<PortfolioHeaderModel>> GetPortfolioHeaderByThemeId(int Theme_id);
        Task<List<PortfolioHeaderModel>> GetPortfolioHeaderById(int portfolio_ID);

        Task<PortfolioHeaderModel> CreateHeader(PortfolioHeaderModel portfolioHeaderModel);
        Task<PortfolioHeaderModel> UpdateHeader(int portfolio_ID, PortfolioHeaderModel portfolioHeaderModel);
        Task<PortfolioHeaderModel> DeleteHeader(int portfolio_ID);

        //Task<PortfolioHeaderModel> Login(PortfolioHeaderModel portfolioHeaderModel);
       // Task<PortfolioHeaderModel> ForgotPassword(string email);
    }
}
