﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MutualFund.Migrations
{
    public partial class one : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Status",
                table: "PortfolioHeaders",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TypeOfPortfolio",
                table: "PortfolioHeaders",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Status",
                table: "PortfolioHeaders");

            migrationBuilder.DropColumn(
                name: "TypeOfPortfolio",
                table: "PortfolioHeaders");
        }
    }
}
