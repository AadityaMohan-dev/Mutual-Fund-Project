﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace MutualFund.Migrations
{
    public partial class fIRST_MIGRATION : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AssetClass",
                columns: table => new
                {
                    Asset_Class_ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Asset_Class = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AssetClass", x => x.Asset_Class_ID);
                });

            migrationBuilder.CreateTable(
                name: "Assetclasses",
                columns: table => new
                {
                    Security_Name = table.Column<string>(nullable: false),
                    Portfolio_ID = table.Column<int>(nullable: false),
                    Price = table.Column<double>(nullable: false),
                    Quantity = table.Column<int>(nullable: false),
                    Total_Transaction = table.Column<double>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Assetclasses", x => x.Security_Name);
                });

            migrationBuilder.CreateTable(
                name: "NSE_Data",
                columns: table => new
                {
                    SYMBOL = table.Column<string>(nullable: false),
                    NAME_OF_COMPANY = table.Column<string>(nullable: true),
                    SERIES = table.Column<string>(nullable: true),
                    DATE_OF_LISTING = table.Column<string>(nullable: true),
                    PAID_UP_VALUE = table.Column<string>(nullable: true),
                    MARKET_LOT = table.Column<string>(nullable: true),
                    ISIN = table.Column<string>(nullable: true),
                    FACE_VALUE = table.Column<string>(nullable: true),
                    SECTOR = table.Column<string>(nullable: true),
                    INDUSTRY = table.Column<string>(nullable: true),
                    EXCHANGE = table.Column<string>(nullable: true),
                    CURRENCY = table.Column<string>(nullable: true),
                    Price = table.Column<string>(nullable: true),
                    AssetClass = table.Column<string>(nullable: true),
                    EquityCategory = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_NSE_Data", x => x.SYMBOL);
                });

            migrationBuilder.CreateTable(
                name: "viewThemes",
                columns: table => new
                {
                    Theme_Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Investment_Theme = table.Column<string>(nullable: true),
                    Investment_Horizon = table.Column<string>(nullable: true),
                    Risk = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_viewThemes", x => x.Theme_Id);
                });

            migrationBuilder.CreateTable(
                name: "Allocations",
                columns: table => new
                {
                    Allocation_ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Allocation_Percentage = table.Column<int>(nullable: false),
                    Theme_Id = table.Column<int>(nullable: false),
                    Asset_Class_ID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Allocations", x => x.Allocation_ID);
                    table.ForeignKey(
                        name: "FK_Allocations_AssetClass_Asset_Class_ID",
                        column: x => x.Asset_Class_ID,
                        principalTable: "AssetClass",
                        principalColumn: "Asset_Class_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Allocations_viewThemes_Theme_Id",
                        column: x => x.Theme_Id,
                        principalTable: "viewThemes",
                        principalColumn: "Theme_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PortfolioHeaders",
                columns: table => new
                {
                    Portfolio_ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Portfolio_Name = table.Column<string>(nullable: false),
                    Base_Currency = table.Column<string>(nullable: false),
                    Bench_Mark = table.Column<string>(nullable: false),
                    Fund_Manager_Name = table.Column<string>(nullable: false),
                    Rebalancing_Frequency = table.Column<string>(nullable: false),
                    Amount_to_be_Invested = table.Column<string>(nullable: false),
                    Returns = table.Column<string>(nullable: false),
                    Theme_Id = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PortfolioHeaders", x => x.Portfolio_ID);
                    table.ForeignKey(
                        name: "FK_PortfolioHeaders_viewThemes_Theme_Id",
                        column: x => x.Theme_Id,
                        principalTable: "viewThemes",
                        principalColumn: "Theme_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PortfolioCompositions",
                columns: table => new
                {
                    Portfolio_Composition_ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Portfolio_ID = table.Column<int>(nullable: false),
                    SYMBOL = table.Column<string>(nullable: false),
                    Transaction_Date = table.Column<DateTime>(nullable: false),
                    Security_Name = table.Column<string>(nullable: false),
                    Equity_Category = table.Column<string>(nullable: false),
                    Exchange_Name = table.Column<string>(nullable: false),
                    Transaction_Type = table.Column<string>(nullable: false),
                    Price = table.Column<double>(nullable: false),
                    Quantity = table.Column<int>(nullable: false),
                    ValueofSecurity = table.Column<double>(nullable: false),
                    Allocation = table.Column<int>(nullable: false),
                    Total_Transaction = table.Column<double>(nullable: false),
                    EstimatedTax = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PortfolioCompositions", x => x.Portfolio_Composition_ID);
                    table.ForeignKey(
                        name: "FK_PortfolioCompositions_PortfolioHeaders_Portfolio_ID",
                        column: x => x.Portfolio_ID,
                        principalTable: "PortfolioHeaders",
                        principalColumn: "Portfolio_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PortfolioCompositions_NSE_Data_SYMBOL",
                        column: x => x.SYMBOL,
                        principalTable: "NSE_Data",
                        principalColumn: "SYMBOL",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Allocations_Asset_Class_ID",
                table: "Allocations",
                column: "Asset_Class_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Allocations_Theme_Id",
                table: "Allocations",
                column: "Theme_Id");

            migrationBuilder.CreateIndex(
                name: "IX_PortfolioCompositions_Portfolio_ID",
                table: "PortfolioCompositions",
                column: "Portfolio_ID");

            migrationBuilder.CreateIndex(
                name: "IX_PortfolioCompositions_SYMBOL",
                table: "PortfolioCompositions",
                column: "SYMBOL");

            migrationBuilder.CreateIndex(
                name: "IX_PortfolioHeaders_Theme_Id",
                table: "PortfolioHeaders",
                column: "Theme_Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Allocations");

            migrationBuilder.DropTable(
                name: "Assetclasses");

            migrationBuilder.DropTable(
                name: "PortfolioCompositions");

            migrationBuilder.DropTable(
                name: "AssetClass");

            migrationBuilder.DropTable(
                name: "PortfolioHeaders");

            migrationBuilder.DropTable(
                name: "NSE_Data");

            migrationBuilder.DropTable(
                name: "viewThemes");
        }
    }
}
