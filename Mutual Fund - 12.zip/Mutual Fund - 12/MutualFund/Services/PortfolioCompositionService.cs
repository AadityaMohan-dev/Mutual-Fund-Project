﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MutualFund.DataAccessLayer;
using MutualFund.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Repository
{
    public class PortfolioCompositionService : IPortfolioComposition
    {
        public readonly MutualDbContext dbContext;
        private readonly ILogger<PortfolioCompositionService> _logger;
        public PortfolioCompositionService(MutualDbContext dbContext, ILogger<PortfolioCompositionService> logger)
        {
            _logger = logger;
            this.dbContext = dbContext;
        }

        public async Task<PortfolioCompositionModel> Createportfolio(PortfolioCompositionModel portfolioCompositionModel)
        {
            try
            {
                _logger.LogInformation("PortfolioComposition Created Successfully");
                dbContext.PortfolioCompositions.Add(portfolioCompositionModel);
                await dbContext.SaveChangesAsync();
                return portfolioCompositionModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<PortfolioCompositionModel>> GetByCompID(int portfolio_Composition_ID)
        {
            try
            {
                _logger.LogInformation("GetByCompID Successfully");
                var ar = await dbContext.PortfolioCompositions.Include(c => c.PortfolioHeaderModel).Include(d => d.usmModel).Where(x => x.Portfolio_Composition_ID == portfolio_Composition_ID).ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }
        public async Task<PortfolioCompositionModel> DeletePortfolio(int portfolio_ID)
        {
            try
            {
                _logger.LogInformation("PortfolioComposition Deleted Successfully");
                var ar = await dbContext.PortfolioCompositions.Where(x => x.Portfolio_Composition_ID == portfolio_ID).FirstOrDefaultAsync();
                if (ar != null)
                {
                    dbContext.PortfolioCompositions.Remove(ar);
                }
                await dbContext.SaveChangesAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<List<PortfolioCompositionModel>> GetAllPortfolios()
        {
            try
            {
                _logger.LogInformation("GetAllPortfolios Successfully");
                var ar = await dbContext.PortfolioCompositions.Include(c => c.PortfolioHeaderModel).Include(d => d.usmModel).ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<List<PortfolioCompositionModel>> GetPortfolioByID(int portfolio_ID)
        {
            try
            {
                _logger.LogInformation("GetPortfolioById Successfully");
                var ar = await dbContext.PortfolioCompositions.Include(c => c.PortfolioHeaderModel).Include(d => d.usmModel).Where(x => x.Portfolio_ID == portfolio_ID).ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<PortfolioCompositionModel> UpdatePortfolio(int portfolio_Composition_ID, PortfolioCompositionModel portfolioCompositionModel)
        {
            try
            {
                _logger.LogInformation("Portfolio Updated Successfully");
                var ar = await dbContext.PortfolioCompositions.Where(x => x.Portfolio_Composition_ID == portfolio_Composition_ID).FirstOrDefaultAsync();
                if (ar != null)
                {
                    ar.SYMBOL = portfolioCompositionModel.SYMBOL;
                    ar.Transaction_Date = portfolioCompositionModel.Transaction_Date;
                    ar.Security_Name = portfolioCompositionModel.Security_Name;
                    //ar.Asset_Class = portfolioCompositionModel.Asset_Class;
                    ar.Equity_Category = portfolioCompositionModel.Equity_Category;
                    ar.Exchange_Name = portfolioCompositionModel.Exchange_Name;
                    ar.Transaction_Type = portfolioCompositionModel.Transaction_Type;
                    //ar.Units = portfolioCompositionModel.Units;
                    ar.Price = portfolioCompositionModel.Price;
                    ar.Quantity = portfolioCompositionModel.Quantity;
                    ar.ValueofSecurity = portfolioCompositionModel.ValueofSecurity;
                    ar.Allocation = portfolioCompositionModel.Allocation;
                    ar.Total_Transaction = portfolioCompositionModel.Total_Transaction;
                    ar.EstimatedTax = portfolioCompositionModel.EstimatedTax;


                }
                await dbContext.SaveChangesAsync();
                return portfolioCompositionModel;

            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }


        }
    }
}


        