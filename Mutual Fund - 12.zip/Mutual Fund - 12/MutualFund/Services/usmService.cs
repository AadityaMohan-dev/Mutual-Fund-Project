﻿using FutureCapitals.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MutualFund.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FutureCapitals.DataAccessLayer
{
    public class usmService : Iusm
    {
        private readonly MutualDbContext dataContext;
        private readonly ILogger<usmService> _logger;

        public usmService(MutualDbContext dataContext, ILogger<usmService> logger)
        {
            this.dataContext = dataContext;
            _logger = logger;

        }

        public async Task<usmModel> CREATENSE(usmModel nSE_data1)
        {
            try
            {
                _logger.LogInformation("NseData Created Successfully");
                dataContext.NSE_Data.Add(nSE_data1);
                await dataContext.SaveChangesAsync();
                return nSE_data1;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<usmModel> DELETENSE(string symbol)
        {
            try
            {
                _logger.LogInformation("NseData Deleted Successfully");
                var del = dataContext.NSE_Data.Where(x => x.SYMBOL == symbol).FirstOrDefault();
                if (del != null)
                {
                    dataContext.NSE_Data.Remove(del);
                }

                await dataContext.SaveChangesAsync();
                return del;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<List<usmModel>> GetByISIN(string isin)
        {
            try
            {
                _logger.LogInformation("GetByIsin  Successfully");
                var ar = await dataContext.NSE_Data.Where(x => x.ISIN == isin).ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<List<usmModel>> GetBySymbol(string symbol)
        {
            try
            {
                _logger.LogInformation("GetBySymbol Successfully");
                var ar = await dataContext.NSE_Data.Where(x => x.SYMBOL == symbol).ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<List<usmModel>> GetSecurities()
        {
            try
            {
                _logger.LogInformation("GetSecurities Successfully");
                var ar = await dataContext.NSE_Data.ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public async Task<usmModel> UPDATENSE(string symbol, usmModel nSE_data1)
        {
            try
            {
                _logger.LogInformation("NseData Updated Successfully");
                var upd = dataContext.NSE_Data.Where(x => x.SYMBOL == symbol).FirstOrDefault();
                if (upd != null)
                {
                    upd.SYMBOL = nSE_data1.SYMBOL;
                    upd.NAME_OF_COMPANY = nSE_data1.NAME_OF_COMPANY;
                    upd.SERIES = nSE_data1.SYMBOL;
                    upd.DATE_OF_LISTING = nSE_data1.DATE_OF_LISTING;
                    upd.PAID_UP_VALUE = nSE_data1.PAID_UP_VALUE;
                    upd.MARKET_LOT = nSE_data1.MARKET_LOT;
                    upd.ISIN = nSE_data1.ISIN;
                    upd.FACE_VALUE = nSE_data1.FACE_VALUE;
                    upd.SECTOR = nSE_data1.SECTOR;
                    upd.INDUSTRY = nSE_data1.INDUSTRY;
                    upd.EXCHANGE = nSE_data1.EXCHANGE;
                    upd.CURRENCY = nSE_data1.CURRENCY;
                    upd.Price = nSE_data1.Price;
                    upd.AssetClass = nSE_data1.AssetClass;
                    upd.EquityCategory = nSE_data1.EquityCategory;
                }

                await dataContext.SaveChangesAsync();
                return upd;

            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }
    }
}


