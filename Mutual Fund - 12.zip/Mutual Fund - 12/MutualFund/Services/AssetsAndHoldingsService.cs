﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MutualFund.DataAccessLayer;
using MutualFund.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.DI
{
    public class AssetsAndHoldingsService : IAssets
    {
        private readonly MutualDbContext dbContext=null;
        private readonly ILogger<AssetsAndHoldingsService> _logger;
        public AssetsAndHoldingsService(MutualDbContext dbContext,ILogger<AssetsAndHoldingsService> logger)
        {
            this.dbContext = dbContext;
           _logger = logger;
        }        

        public async Task<AssetsAndHoldingsModel> CreateAsset(AssetsAndHoldingsModel assetsModels)
        {
            try
            {
               _logger.LogInformation("AssetAndHoldings Created Successfully");
                dbContext.Assetclasses.Add(assetsModels);
                await dbContext.SaveChangesAsync();
                return assetsModels;
            }
            catch (Exception ex)
            {
                throw ex;
                
            }
            
        }

        public async Task<AssetsAndHoldingsModel> DeleteAsset(string security_Name)
        {
            try
            {
                _logger.LogInformation("AssetAndHoldings Deleted Successfully");
                var ar = await dbContext.Assetclasses.Where(x => x.Security_Name == security_Name).FirstOrDefaultAsync();
                if (ar != null)
                {
                    dbContext.Assetclasses.Remove(ar);
                }
                await dbContext.SaveChangesAsync();
                return ar;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<AssetsAndHoldingsModel>> GetAllAssets()
        {
            try
            {
                _logger.LogInformation("GetAllAssets Successfully");
                var ar = await dbContext.Assetclasses.ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {
                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<List<AssetsAndHoldingsModel>> GetAssetsByName(string security_Name)
        {
            try
            {
                _logger.LogInformation("GetAssetsByName Successfully");
                var ar = await dbContext.Assetclasses.Where(x => x.Security_Name == security_Name).ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {
                _logger.LogError("Sql Error");
                throw ex;
            }
        }


        public async Task<AssetsAndHoldingsModel> UpdateAsset(string security_Name, AssetsAndHoldingsModel assetsModels)
        {
            try
            {
                _logger.LogInformation("Asset Updated Successfully");
                var ar = await dbContext.Assetclasses.Where(x => x.Security_Name == security_Name).FirstOrDefaultAsync();
                if (ar != null)
                {
                    ar.Portfolio_ID = assetsModels.Portfolio_ID;
                    ar.Price = assetsModels.Price;
                    ar.Quantity = assetsModels.Quantity;
                    ar.Total_Transaction = assetsModels.Total_Transaction;


                }
                await dbContext.SaveChangesAsync();
                return ar;
            }
            catch (Exception)
            {
                _logger.LogInformation("Sql Error");
                throw;
            }
        }
    }
}
