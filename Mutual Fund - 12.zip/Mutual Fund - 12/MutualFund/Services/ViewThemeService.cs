﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MutualFund.DataAccessLayer;
using MutualFund.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.DI
{
    public class ViewThemeService : IViewTheme
    {
        public readonly MutualDbContext dbContext=null;
        private readonly ILogger<ViewThemeService> _logger;
        public ViewThemeService(MutualDbContext dbContext,ILogger<ViewThemeService> logger)
        {
            this.dbContext = dbContext;
            _logger = logger;

        }
        public async Task<ViewThemeModel> CreateTheme(ViewThemeModel themesModel)
        {
            try
            {
                _logger.LogInformation("Themes Created Successfully");
                dbContext.viewThemes.Add(themesModel);
                await dbContext.SaveChangesAsync();
                return themesModel;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<ViewThemeModel> DeleteTheme(int theme_Id)
        {
            try
            {
                _logger.LogInformation("Theme Deleted Successfully");
                var ar = await dbContext.viewThemes.Where(x => x.Theme_Id == theme_Id).FirstOrDefaultAsync();
                if (ar != null)
                {
                    dbContext.viewThemes.Remove(ar);
                }
                await dbContext.SaveChangesAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<List<ViewThemeModel>> GetAllThemes()
        {
            try
            {
                _logger.LogInformation("GetAllThemes Successfully");
                var ar = await dbContext.viewThemes.ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<List<ViewThemeModel>> GetThemesByThemeID(int theme_Id)
        {
            try
            {
                _logger.LogInformation("GetThemesByType Successfully");
                var ar = await dbContext.viewThemes.Where(x => x.Theme_Id == theme_Id).ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<ViewThemeModel> UpdateTheme(int theme_Id, ViewThemeModel themesModel)
        {
            try
            {
                _logger.LogInformation("Theme Updated Successfully");
                var ar = await dbContext.viewThemes.Where(x => x.Theme_Id == theme_Id).FirstOrDefaultAsync();
                if (ar != null)
                {

                    ar.Investment_Horizon = themesModel.Investment_Horizon;
                    ar.Risk = themesModel.Risk;
                    ar.Investment_Theme = themesModel.Investment_Theme;
                    //ar.Allocation = themesModel.Allocation;
                    //ar.Mix_Investments = themesModel.Mix_Investments;

                }
                await dbContext.SaveChangesAsync();
                return themesModel;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<List<ViewThemeModel>> GetThemeDescending()
        {
            try
            {
                _logger.LogInformation("GetAllThemes in Descending Successfully");
                var ar = await dbContext.viewThemes.OrderByDescending(x => x.Theme_Id).ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
    }
}

