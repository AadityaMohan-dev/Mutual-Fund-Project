﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MutualFund.DataAccessLayer;
using MutualFund.Models;
using MutualFund.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Services
{
    public class AssetClassService : IAssetClass
    {
        private readonly MutualDbContext dbContext = null;
        private readonly ILogger<AssetClassService> _logger;
        public AssetClassService(MutualDbContext dbContext, ILogger<AssetClassService> logger)
        {
            this.dbContext = dbContext;
            _logger = logger;
        }
        public async Task<AssetClassesModel> CreateAssetClass(AssetClassesModel assetClassesModel)
        {
            try
            {
                _logger.LogInformation("AssetClass Created Successfully");
                dbContext.AssetClass.Add(assetClassesModel);
                await dbContext.SaveChangesAsync();
                return assetClassesModel;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public async Task<List<AssetClassesModel>> GetAllAssetClasses()
        {
            try
            {
                _logger.LogInformation("GetAllClasses Successfully");
                var ar = await dbContext.AssetClass.ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<List<AssetClassesModel>> GetAssetClassByID(int asset_ID)
        {
            try
            {
                _logger.LogInformation("GetAssetClassById Successfully");
                var ar = await dbContext.AssetClass.Where(x => x.Asset_Class_ID == asset_ID).ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<AssetClassesModel> UpdateAssetClass(int asset_ID, AssetClassesModel assetClassesModel)
        {
            try
            {
                _logger.LogInformation("UpdateAssetClass Successfully");
                var ar = await dbContext.AssetClass.Where(x => x.Asset_Class_ID == asset_ID).FirstOrDefaultAsync();
                if (ar != null)
                {
                    ar.Asset_Class = assetClassesModel.Asset_Class;
                }
                await dbContext.SaveChangesAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }
        public async Task<AssetClassesModel> DeleteAssetClass(int asset_ID)
        {
            try
            {
                _logger.LogInformation("AssetClass Successfully");
                var ar = await dbContext.AssetClass.Where(x => x.Asset_Class_ID == asset_ID).FirstOrDefaultAsync();
                if (ar != null)
                {
                    dbContext.AssetClass.Remove(ar);
                }
                await dbContext.SaveChangesAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }
    }
}


