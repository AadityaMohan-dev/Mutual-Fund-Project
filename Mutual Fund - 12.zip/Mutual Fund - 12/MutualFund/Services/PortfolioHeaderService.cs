﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MutualFund.DataAccessLayer;
using MutualFund.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.DI
{
    public class PortfolioHeaderService : IPortfolioHeader
    {
        private readonly MutualDbContext dbContext;
        private readonly ILogger<PortfolioHeaderService> _logger;
        public PortfolioHeaderService(MutualDbContext dbContext, ILogger<PortfolioHeaderService> logger)
        {
            _logger = logger;
            this.dbContext = dbContext;
        }

        public async Task<PortfolioHeaderModel> CreateHeader(PortfolioHeaderModel portfolioHeaderModel)
        {
            try
            {
                _logger.LogInformation("PortfolioHeader Created Successfully");
                portfolioHeaderModel.Status = "New";
                dbContext.PortfolioHeaders.Add(portfolioHeaderModel);
                await dbContext.SaveChangesAsync();
                return portfolioHeaderModel;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<PortfolioHeaderModel> DeleteHeader(int portfolio_ID)
        {
            try
            {
                _logger.LogInformation("PortfolioHeader Deleted Successfully");
                var ar = await dbContext.PortfolioHeaders.Where(x => x.Portfolio_ID == portfolio_ID).FirstOrDefaultAsync();
                if (ar != null)
                {
                    dbContext.PortfolioHeaders.Remove(ar);
                }
                await dbContext.SaveChangesAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<List<PortfolioHeaderModel>> GetAllPortfolioHeader()
        {
            try
            {
                _logger.LogInformation("GetAllPortfolioHeader Successfully");
                var ar = await dbContext.PortfolioHeaders.Include(o => o.ViewThemeModel).ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<List<PortfolioHeaderModel>> GetPortfolioHeaderById(int portfolio_ID)
        {
            try
            {
                _logger.LogInformation("GetPortfolioHeaderById Successfully");
                var ar = await dbContext.PortfolioHeaders.Include(o => o.ViewThemeModel).Where(x => x.Portfolio_ID == portfolio_ID).ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<List<PortfolioHeaderModel>> GetPortfolioHeaderByName(string portfolio_Name)
        {
            try
            {
                _logger.LogInformation("AssetAndHoldings Created Successfully");
                var ar = await dbContext.PortfolioHeaders.Include(o => o.ViewThemeModel).Where(x => x.Portfolio_Name == portfolio_Name).ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }


        public async Task<PortfolioHeaderModel> UpdateHeader(int portfolio_ID, PortfolioHeaderModel portfolioHeaderModel)
        {
            try
            {
                _logger.LogInformation("Portfolio Updated Successfully");
                var ar = await dbContext.PortfolioHeaders.Where(x => x.Portfolio_ID == portfolio_ID).FirstOrDefaultAsync();
                if (ar != null)
                {
                    //ar.Portfolio_ID = portfolioHeaderModel.Portfolio_ID;
                    ar.Portfolio_Name = portfolioHeaderModel.Portfolio_Name;
                    ar.Base_Currency = portfolioHeaderModel.Base_Currency;
                    ar.Bench_Mark = portfolioHeaderModel.Bench_Mark;
                    ar.Fund_Manager_Name = portfolioHeaderModel.Fund_Manager_Name;
                    ar.Rebalancing_Frequency = portfolioHeaderModel.Rebalancing_Frequency;
                    ar.Amount_to_be_Invested = portfolioHeaderModel.Amount_to_be_Invested;
                    ar.Theme_Id = portfolioHeaderModel.Theme_Id;
                    ar.Status = portfolioHeaderModel.Status;
                    ar.TypeOfPortfolio = portfolioHeaderModel.TypeOfPortfolio;
                    ar.Returns = portfolioHeaderModel.Returns;
                }
                await dbContext.SaveChangesAsync();
                return portfolioHeaderModel;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }


        }
    }
}


