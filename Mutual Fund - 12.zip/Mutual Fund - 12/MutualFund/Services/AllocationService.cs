﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MutualFund.DataAccessLayer;
using MutualFund.Models;
using MutualFund.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Services
{
    public class AllocationService : IAllocations
    {
        private readonly MutualDbContext dbContext = null;
        private readonly ILogger<AllocationService> _logger;
        public AllocationService(MutualDbContext dbContext,ILogger<AllocationService> logger)
        {
            this.dbContext = dbContext;
            _logger = logger;
        }
        public async Task<AllocationsModel> CreateAllocations(AllocationsModel allocationsModel)
        {
            try
            {
                _logger.LogInformation("Allocations Created Successfully");
                dbContext.Allocations.Add(allocationsModel);
                await dbContext.SaveChangesAsync();
                return allocationsModel;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<AllocationsModel> DeleteAllocations(int allocation_ID)
        {
            try
            {
                _logger.LogInformation("Allocations Deleted Successfully");
                var ar = await dbContext.Allocations.Where(x => x.Allocation_ID == allocation_ID).FirstOrDefaultAsync();
                if (ar != null)
                {
                    dbContext.Allocations.Remove(ar);
                }
                await dbContext.SaveChangesAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<List<AllocationsModel>> GetAllAllocations()
        {
            try
            {
                _logger.LogInformation("GetAllAllocations Successfully");
                var ar = await dbContext.Allocations.Include(c => c.ViewThemeModel).Include(d => d.AssetClassesModel).ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<List<AllocationsModel>> GetAllocationsByID(int allocation_Id)
        {
            try
            {
                _logger.LogInformation("GetAllocationsByID Successfully");
                var ar = await dbContext.Allocations.Include(c=>c.ViewThemeModel).Include(d => d.AssetClassesModel).Where(x => x.Allocation_ID == allocation_Id).ToListAsync();
                return ar;
            }
            catch(Exception ex)
            {
                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        public async Task<List<AllocationsModel>> GetAllocationsByThemeID(int theme_Id)
        {
            try
            {
                _logger.LogInformation("GetAllocationsByThemeId Successfully");
                var ar = await dbContext.Allocations.Include(c=>c.ViewThemeModel).Include(d => d.AssetClassesModel).Where(x => x.Theme_Id == theme_Id).ToListAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

       public double SUMByTheme(int themeID)
        {
            var sum = dbContext.Allocations.Where(x => x.Theme_Id == themeID).Select(i => Convert.ToDouble(i.Allocation_Percentage)).Sum();
            return Convert.ToDouble(sum);
        }

        public async Task<AllocationsModel> UpdateAllocationByThemeID(int theme_ID, int Asset_ID, AllocationsModel allocationsModel)
        {
            try
            {
                _logger.LogInformation("Allocations Updated Successfully");
                var ar = await dbContext.Allocations.Where(x => x.Theme_Id == theme_ID && x.Asset_Class_ID == Asset_ID).FirstOrDefaultAsync();
                if (ar != null)
                {
                    ar.Allocation_Percentage = allocationsModel.Allocation_Percentage;
                }
                await dbContext.SaveChangesAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

       


        public async Task<AllocationsModel> UpdateAllocations(int allocation_ID, AllocationsModel allocationsModel)
        {
            try
            {
                _logger.LogInformation("Allocations Updated Successfully");
                var ar = await dbContext.Allocations.Where(x => x.Allocation_ID == allocation_ID).FirstOrDefaultAsync();
                if (ar != null)
                {
                    ar.Allocation_Percentage = allocationsModel.Allocation_Percentage;

                }
                await dbContext.SaveChangesAsync();
                return ar;
            }
            catch (Exception ex)
            {

                _logger.LogError("Sql Error");
                throw ex;
            }
        }

        

    }
    }

