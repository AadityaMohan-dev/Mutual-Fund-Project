﻿using FutureCapitals.Models;
using System.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using MutualFund.Models;
using System.Globalization;
using System.IO;
using CsvHelper;


namespace MutualFund.DataAccessLayer
{
    public class MutualDbContext : DbContext
    {
        public MutualDbContext(DbContextOptions<MutualDbContext> options) : base(options)
        {

        }
        public DbSet<AssetsAndHoldingsModel> Assetclasses { get; set; }
        public DbSet<PortfolioHeaderModel> PortfolioHeaders { get; set; }
        public DbSet<PortfolioCompositionModel> PortfolioCompositions { get; set; }
        public DbSet<ViewThemeModel> viewThemes { get; set; }
        public DbSet<usmModel> NSE_Data { get; set; }
        public DbSet<AssetClassesModel> AssetClass{ get; set; }
        public DbSet<AllocationsModel> Allocations { get; set; }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        ////    modelBuilder.Entity<PortfolioHeaderModel>()
        //        .HasOne(o => o.ThemesModel)
        //        .WithMany(c => c.PortfolioHeaderModels)
        //        .HasForeignKey(o => o.Theme_Id);
        //}


        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    var connectionString = "server=10.3.117.39;Database=ABW6_Portfolio;Integrated security=True;";

        //    using (var connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();
        //        using (var reader = new StreamReader("C:/Users/2000080627/Documents/db/USMUpdated.csv"))
        //        using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
        //        {
        //            //   csv.Configuration.HeaderValidated = null;
        //            //  csv.Configuration.MissingFieldFound = null;
        //            var records = csv.GetRecords<usmModel>();

        //            foreach (var record in records)
        //            {
        //                var cc = new SqlCommand("INSERT INTO NSE_Data(SYMBOL, NAME_OF_COMPANY ,SERIES , DATE_OF_LISTING, PAID_UP_VALUE, MARKET_LOT, ISIN, FACE_VALUE, SECTOR, INDUSTRY, EXCHANGE,CURRENCY, Price, AssetClass, EquityCategory) VALUES (@Column1, @Column2, @Column3, @Column4, @Column5, @Column6, @Column7, @Column8, @Column9, @Column10, @Column11, @Column12, @Column13, @Column14, @Column15)", connection);
        //                cc.Parameters.AddWithValue("@Column1", record.SYMBOL);
        //                cc.Parameters.AddWithValue("@Column2", record.NAME_OF_COMPANY);
        //                cc.Parameters.AddWithValue("@Column3", record.SERIES);
        //                cc.Parameters.AddWithValue("@Column4", record.DATE_OF_LISTING);
        //                cc.Parameters.AddWithValue("@Column5", record.PAID_UP_VALUE);
        //                cc.Parameters.AddWithValue("@Column6", record.MARKET_LOT);
        //                cc.Parameters.AddWithValue("@Column7", record.ISIN);
        //                cc.Parameters.AddWithValue("@Column8", record.FACE_VALUE);
        //                cc.Parameters.AddWithValue("@Column9", record.SECTOR);
        //                cc.Parameters.AddWithValue("@Column10", record.INDUSTRY);
        //                cc.Parameters.AddWithValue("@Column11", record.EXCHANGE);
        //                cc.Parameters.AddWithValue("@Column12", record.CURRENCY);
        //                cc.Parameters.AddWithValue("@Column13", record.Price);
        //                cc.Parameters.AddWithValue("@Column14", record.AssetClass);
        //                cc.Parameters.AddWithValue("@Column15", record.EquityCategory);
        //                cc.ExecuteNonQuery();

        //            }
        //        }

        //        connection.Close();
        //    }
        //}



    }
}
