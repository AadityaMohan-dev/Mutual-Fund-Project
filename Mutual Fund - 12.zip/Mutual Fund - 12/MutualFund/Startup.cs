using FutureCapitals.DataAccessLayer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using MutualFund.DataAccessLayer;
using MutualFund.DI;
using MutualFund.Repository;
using MutualFund.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddScoped<IAssets,AssetsAndHoldingsService>();
            services.AddScoped<IViewTheme, ViewThemeService>();
            services.AddScoped<IPortfolioHeader, PortfolioHeaderService>();
            services.AddScoped<Iusm, usmService>();
            services.AddScoped<IPortfolioComposition, PortfolioCompositionService>();
            services.AddScoped<IAssetClass, AssetClassService>();
            services.AddScoped<IAllocations, AllocationService>();

            services.AddApiVersioning(config =>
            {
                config.DefaultApiVersion = new ApiVersion(1, 0);
                config.AssumeDefaultVersionWhenUnspecified = true;
                config.ReportApiVersions = true;

                //config.ApiVersionReader = new HeaderApiVersionReader("custom-version-header");
                //config.ApiVersionReader = new MediaTypeApiVersionReader();
            });

            services.AddSwaggerGen(); services.AddSwaggerGen(c =>
            { c.SwaggerDoc("v1", new OpenApiInfo { Version = "v1", Title = "ProjectAPI", Description = "A simple example to Implement Swagger UI", }); });
            services.AddDbContext<MutualDbContext>(option => option.UseSqlServer(Configuration.GetConnectionString("MConnection")));

            services.AddCors(options => options.AddDefaultPolicy(builder => builder.WithOrigins("*").AllowAnyHeader()
            .AllowAnyMethod().AllowAnyOrigin()));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseCors(options => options.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());

            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();
            app.UseCors();

            app.UseAuthorization();
            app.UseSwagger();
            app.UseSwaggerUI(c => { c.SwaggerEndpoint("/swagger/v1/swagger.json", "Showing API V1"); });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
