﻿using FutureCapitals.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Models
{
    public class PortfolioCompositionModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required(ErrorMessage = "PortfolioCompositionID")]
        public int Portfolio_Composition_ID { get; set; }


        [ForeignKey("PortfolioHeaderModel")]
        [Required(ErrorMessage = "Portfolio_ID")]
        public int Portfolio_ID { get; set; }
        public virtual PortfolioHeaderModel? PortfolioHeaderModel { get; set; }

        

        [ForeignKey("usmModel")]
        [Required(ErrorMessage = "SYMBOL")]
        public string SYMBOL { get; set; }
        public virtual usmModel? usmModel { get; set; }
        
        [Required(ErrorMessage = "TransactionDate")]
        public DateTime Transaction_Date { get; set; }
        [Required(ErrorMessage = "SecurityName")]
        public string Security_Name { get; set; }
        //[Required(ErrorMessage = "AssetClass")]
        //public string Asset_Class { get; set; }
        [Required(ErrorMessage = "EquityCategory")]
        public string Equity_Category { get; set; }
        [Required(ErrorMessage = "ExchangeName")]
        public string Exchange_Name { get; set; }
        [Required(ErrorMessage = "TransactionType")]
        public string Transaction_Type { get; set; }
        [Required(ErrorMessage = "Units")]
        //public int Units { get; set; }
        //[Required(ErrorMessage = "Price")]
        public double Price { get; set; }
        [Required(ErrorMessage = "Quantity")]
        public int Quantity { get; set; }
        [Required(ErrorMessage = "ValueofSecurity")]
        public double ValueofSecurity { get; set; }
        [Required(ErrorMessage = "Allocation")]
        public int Allocation { get; set; }
        [Required(ErrorMessage = "TotalTransaction")]
        public double Total_Transaction { get; set; }
        [Required(ErrorMessage = "EstimatedTax")]
        public int EstimatedTax { get; set; }


        //public virtual usmModel NSE_data { get; set; }//navigation property
       // public virtual PortfolioHeaderModel PortfolioHeaders { get; set; }

    }
}
