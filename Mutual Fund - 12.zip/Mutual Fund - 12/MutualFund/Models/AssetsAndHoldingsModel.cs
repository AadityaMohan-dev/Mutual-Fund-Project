﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Models
{
    public class AssetsAndHoldingsModel
    {
        //[ForeignKey("PortfolioHeaders")]
        public int Portfolio_ID { get; set; }
        [Key]
        public string Security_Name { get; set; }
        public double Price { get; set; }
        public int Quantity { get; set; }
        public double Total_Transaction { get; set; }

        //public virtual PortfolioHeaderModel PortfolioHeaderModel { get; set; }
        }
    }

