﻿using MutualFund.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FutureCapitals.Models
{
    public class usmModel
    {
        [Key]
        
        public string SYMBOL { get; set; }

        public string NAME_OF_COMPANY { get; set; }

        public string SERIES { get; set; }

        public string DATE_OF_LISTING { get; set; }

        public string PAID_UP_VALUE { get; set; }

        public string MARKET_LOT { get; set; }
        
        public string ISIN { get; set; }

        public string FACE_VALUE { get; set; }
        public string SECTOR { get; set; }
        public string INDUSTRY { get; set; }
        public string EXCHANGE { get; set; }
        public string CURRENCY { get; set; }
        public string Price { get; set; }
        public string AssetClass { get; set; }
        public string EquityCategory { get; set; }



        //public virtual ICollection<PortfolioCompositionModel> PortfolioCompositions { get; set; }

    }
}
