﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace MutualFund.Models
{
    public class PortfolioHeaderModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required(ErrorMessage = "PortfolioID")]
        public int Portfolio_ID { get; set; }

        
        [Required(ErrorMessage = "Portfolio_Name")]
        public string Portfolio_Name { get; set; }

        //[Required(ErrorMessage = "Type of Portfolio")]
        //public string Type_of_Portfolio { get; set; }

        [Required(ErrorMessage = "Enter Currency")]
        public string Base_Currency { get; set; }

        
        
        [Required(ErrorMessage = "Enter BenchMark")]
        public string Bench_Mark { get; set; }

        
        
        [Required(ErrorMessage = "FundManagerName")]
        public string Fund_Manager_Name { get; set; }

        //[Required(ErrorMessage = "Enter Email")]
        //[DataType(DataType.EmailAddress)]
        
        //public string Email { get; set; }

        //[Required(ErrorMessage = "Enter Password")]
        //[DataType(DataType.Password)]
        //public string Password { get; set; }

        //[Required(ErrorMessage = "Confirm Password and should match the above password")]
        //[DataType(DataType.Password)]
        //[Compare("Password")]
        //public string ConfirmPassword { get; set; }

        
        
        [Required(ErrorMessage = "Enter Rebalancing Frequency")]
        public string Rebalancing_Frequency { get; set; }

        
        
        
        [Required(ErrorMessage = "Enter Amount to be Invested")]
        public string Amount_to_be_Invested { get; set; }
       
        
        
        [Required(ErrorMessage = "Returns")]
        public string Returns { get; set; }

        public string Status { get; set; }
        public string TypeOfPortfolio { get; set; }
        [ForeignKey("ViewThemeModel")]
        [Required(ErrorMessage = "Theme_Id")]
        public int Theme_Id { get; set; }
        //public virtual ThemesModel? ThemesModel { get; set; }


        public virtual ViewThemeModel? ViewThemeModel { get; set; }


        //public virtual ICollection<PortfolioCompositionModel> PortfolioCompositions { get; set; }
        //public virtual ICollection<AssetsModels> AssetsModel { get; set; }



    }
}
