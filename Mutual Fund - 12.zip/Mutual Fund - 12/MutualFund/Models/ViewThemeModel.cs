﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Models
{
    public class ViewThemeModel
    {      
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Theme_Id { get; set; }
        public string Investment_Theme { get; set; }
        public string Investment_Horizon { get; set; }
        public string ThemeDescription { get; set; }
        public string Risk { get; set; }
       


    }
}
