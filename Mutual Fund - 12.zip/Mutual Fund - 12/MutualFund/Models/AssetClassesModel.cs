﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Models
{
    public class AssetClassesModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Asset_Class_ID { get; set; }
        public string Asset_Class { get; set; }
        //public string Asset_Description { get; set; }
        //public string Sub_Asset_Class { get; set; }
        //public string Sub_Asset_Description { get; set; }
    }
}
