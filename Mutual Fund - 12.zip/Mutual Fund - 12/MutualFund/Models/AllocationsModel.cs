﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Models
{
    public class AllocationsModel
    {

        [Key]
        public int Allocation_ID { get; set; }
        public int Allocation_Percentage { get; set; }


        [ForeignKey("ViewThemeModel")]
        public int Theme_Id { get; set; }
        public virtual ViewThemeModel? ViewThemeModel { get; set; }


        [ForeignKey("AssetClassesModel")]
        public int Asset_Class_ID { get; set; }
        public virtual AssetClassesModel? AssetClassesModel { get; set; }
    }
}
