﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MutualFund.Models;
using MutualFund.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class AllocationsController : ControllerBase
    {
        private readonly IAllocations alloc;
        public AllocationsController(IAllocations alloc)
        {
            
            this.alloc = alloc;
        }
        [HttpPost]
        [Route("CreateAllocations")]
        public async Task<IActionResult> CreateAllocations(AllocationsModel allocationsModel)
        {
            var a = await alloc.CreateAllocations(allocationsModel);
            return Ok(a);
        }
        [HttpPut]
        [Route("UpdateAllocations")]
        public async Task<IActionResult> UpdateAllocations(int allocation_ID, AllocationsModel allocationsModel)
        {
            var a = await alloc.UpdateAllocations(allocation_ID, allocationsModel);
            return Ok(a);
        }

      
        [HttpPut]
        [Route("UpdateAllocationsByTheme&Asset")]
        public async Task<IActionResult> UpdateAllocationByThemeID(int theme_ID, int asset_ID, AllocationsModel allocationsModel)
        {
            var a = await alloc.UpdateAllocationByThemeID(theme_ID, asset_ID, allocationsModel);
            return Ok(a);
        }

        [HttpDelete]
        [Route("DeleteAllocations")]
        public async Task<IActionResult> DeleteAllocations(int allocation_ID)
        {
            var a = await alloc.DeleteAllocations(allocation_ID);
            return Ok(a);
        }

        [HttpGet]
        [Route("GetAllocationsByThemeID)")]
        public async Task<IActionResult> GetAllocationsByThemeID(int theme_Id)
        {
            var pt = await alloc.GetAllocationsByThemeID(theme_Id);
            if (pt != null)
            {
                return Ok(pt);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpGet]
        [Route("GetAllocationsByID)")]
        public async Task<IActionResult> GetAllocationsByID(int allocation_Id)
        {
            var pt = await alloc.GetAllocationsByID(allocation_Id);
            if (pt != null)
            {
                return Ok(pt);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpGet]
        [Route("GetAllAllocations")]
        public async Task<IActionResult> GetAllAllocations()
        {
            var a = await alloc.GetAllAllocations();
            return Ok(a);
        }

        [HttpGet]
        [Route("SUMByTheme/{themeid}")]
        public double SUMByTheme(int themeid)
        {
            var a = alloc.SUMByTheme(themeid);
            return a;
        }
    }
}
