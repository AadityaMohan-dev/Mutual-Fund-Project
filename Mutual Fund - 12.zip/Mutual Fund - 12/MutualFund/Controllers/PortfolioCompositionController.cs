﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
//using MutualFund.Model;
using MutualFund.Models;
using MutualFund.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Controller
{
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class PortfolioCompositionController : ControllerBase
    {
        private readonly IPortfolioComposition _repository;
        private readonly ILogger<PortfolioCompositionController> _logger;
        public PortfolioCompositionController(IPortfolioComposition repository,ILogger<PortfolioCompositionController> logger)
        {
            _repository = repository;
            _logger = logger;
        }


        [HttpPost]
        [Route("Createportfolio")]

        public async Task<ActionResult> Createportfolio(PortfolioCompositionModel portfolioCompositionModel)
        {
            _logger.LogInformation("Portfolio Created Successfully");
            var ar = await _repository.Createportfolio(portfolioCompositionModel);
            return Ok(ar);
        }


        [HttpPut]
        [Route("UpdatePortfolio")]
        public async Task<IActionResult> UpdatePortfolio(int portfolio_Composition_ID, PortfolioCompositionModel portfolioCompositionModel)
        {
            _logger.LogInformation("Portfolio Updated Successfully");
            PortfolioCompositionModel a = await _repository.UpdatePortfolio(portfolio_Composition_ID, portfolioCompositionModel);
            return Ok(a);
        }


        [HttpDelete]
        [Route("DeletePortfolio")]
        public async Task<ActionResult> DeletePortfolio(int portfolio_ID)
        {
            _logger.LogInformation("Portfolio Deleted Successfully");
            var ar = await _repository.DeletePortfolio(portfolio_ID);
            return Ok(ar);
        }


        [HttpGet("GetPortfolioByID")]
        public async Task<IActionResult> GetPortfolioByID(int portfolio_ID)
        {
            _logger.LogInformation("GetPortfolioById Successfully");
            var pt = await _repository.GetPortfolioByID(portfolio_ID);
            if (pt != null)
            {
                return Ok(pt);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpGet("GetByCompID")]
        public async Task<IActionResult> GetByCompID(int portfolio_Composition_ID)
        {
            _logger.LogInformation("GetPortfolioById Successfully");
            var pt = await _repository.GetByCompID(portfolio_Composition_ID);
            if (pt != null)
            {
                return Ok(pt);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        [Route("GetAllPortfolios")]
        public async Task<ActionResult> GetAllPortfolios()
        {
            _logger.LogInformation("GetAllPortfolios");
            List<PortfolioCompositionModel> flightsinfo = await _repository.GetAllPortfolios();
            return Ok(flightsinfo);

        }
        
       
    }
}
