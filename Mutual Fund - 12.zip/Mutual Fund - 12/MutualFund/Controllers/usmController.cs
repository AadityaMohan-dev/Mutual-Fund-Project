﻿using FutureCapitals.DataAccessLayer;
using FutureCapitals.Models;
//using log4net;
//using log4net.Repository.Hierarchy;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MutualFund.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace FutureCapitals.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class usmController : ControllerBase
    {
       
        private readonly Iusm dataContext;
        private readonly MutualDbContext dbContext;
        private readonly ILogger<usmController> _logger;
        //private static readonly ILog log = LogManager.GetLogger(typeof(NSE_data1Controller));

        public usmController(Iusm dataContext,MutualDbContext dbContext,ILogger<usmController> logger)
        {
            _logger = logger;
            this.dataContext = dataContext;
            this.dbContext = dbContext;
        }

        [HttpGet]
        [Route("Securities")]
        public async Task<IActionResult> GetSecurities()
        {
            //log.Info("get securities accessed");

            _logger.LogInformation("GetSeurities Successfully");
            var info = await dataContext.GetSecurities();
            return Ok(info);
        }


        [HttpPost]//Add securities 
        [Route("Add")]
        public async Task<IActionResult> CREATENSE(usmModel nSE_Export)
        {
            _logger.LogInformation("NseData Created Successfully");
            usmModel ar = await dataContext.CREATENSE(nSE_Export);
            return Ok(ar);

        }

        [HttpPut]
        [Route("updatedata")]
        public async Task<IActionResult> UPDATENSE(string symbol, usmModel nSE_Data1)
        {
            _logger.LogInformation("NseData Updated Successfully");
            usmModel a = await dataContext.UPDATENSE(symbol,nSE_Data1);
            return Ok(a);
        }
        /*[HttpPut]//Update securities
        [Route("Update")]
        public IActionResult UpdateNSEdata(NSE_data1 nSE_update)
        {
            _dataContext.Update(nSE_update);
            _dataContext.SaveChanges();
            return NoContent();
        }*/
        [HttpDelete]//Delete securities
        [Route("DeleteAsset")]
        public async Task<IActionResult>DELETENSE(string symbol)
        {
            _logger.LogInformation("NseAsset Deleted Successfully");
            usmModel a = await dataContext.DELETENSE(symbol);
            return Ok(a);
        }



        [HttpGet]//Get by ISIN and CompanyName
        [Route("Details")]
      
            public async Task<ActionResult<usmModel>> DetailsWithData(string option)

            {
                option = option.ToLower();

                var stor = await dbContext.NSE_Data.Where(x => x.ISIN.Contains(option)
                || x.NAME_OF_COMPANY.Contains(option)
                || x.SYMBOL.Contains(option)
                || x.EquityCategory.Contains(option)
                || x.AssetClass.Contains(option)).ToListAsync();

                if (stor == null)
                {
                    return NotFound();
                }
                return Ok(stor);
            }
        }



            //[HttpGet("{ISIN}")]
            //public async Task<ActionResult<NSE_data1>> Getdata(string ISIN)
            // var info1 = await _dataContext.NSE_Data1.FindAsync(ISIN);

            // if (info1 == null)
            // {
            //     return NotFound();
            //  }

            //return info1;

            //}






        }
    


