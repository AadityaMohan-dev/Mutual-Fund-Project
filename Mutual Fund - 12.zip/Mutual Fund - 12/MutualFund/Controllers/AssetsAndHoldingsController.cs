﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MutualFund.DataAccessLayer;
using MutualFund.DI;
using MutualFund.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class AssetsAndHoldingsController : ControllerBase
    {
        private readonly IAssets asset = null;
        public AssetsAndHoldingsController(IAssets asset)
        { 
            this.asset = asset;
        }
        [HttpPost]
        [Route("CreateAsset")]
        public async Task<IActionResult> CreateAsset([FromBody] AssetsAndHoldingsModel assetsModels)
        {
            AssetsAndHoldingsModel a = await asset.CreateAsset(assetsModels);
            return Ok(a);
        }
        [HttpPut]
        [Route("UpdateAsset")]
        public async Task<IActionResult> UpdateAsset(string security_Name, AssetsAndHoldingsModel assetsModels)
        {
            AssetsAndHoldingsModel a = await asset.UpdateAsset(security_Name, assetsModels);
            return Ok(a);
        }
        [HttpDelete]
        [Route("DeleteAsset")]
        public async Task<IActionResult> DeleteAsset(string security_Name)
        {
            AssetsAndHoldingsModel a = await asset.DeleteAsset(security_Name);
            return Ok(a);
        }

        [HttpGet("GetAssetsByType/{Security_Name}")]
        public async Task<IActionResult> GetAssetsByType(string security_Name)
        {
            var pt = await asset.GetAssetsByName(security_Name);
            if (pt != null)
            {
                return Ok(pt);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpGet]
        [Route("GetAllAssets")]
        public async Task<IActionResult> GetAllAssets()
        {
            var a = await asset.GetAllAssets();
            return Ok(a);
        }
    }
}
