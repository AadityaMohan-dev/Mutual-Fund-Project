﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MutualFund.DataAccessLayer;
using MutualFund.DI;
using MutualFund.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class ViewThemeController : ControllerBase
    {
        //public readonly MutualDbContext dbContext = null;
        private readonly IViewTheme theme = null;
        private readonly ILogger<ViewThemeController> _logger;
        public ViewThemeController(IViewTheme theme,ILogger<ViewThemeController> logger)
        {
            this.theme = theme;
            _logger = logger;
            //this.dbContext = dbContext;
        }
        [HttpPost]
        [Route("CreateTheme")]
        public async Task<IActionResult> CreateTheme([FromBody] ViewThemeModel themesModel)
        {
            _logger.LogInformation("Theme create Successfully");
            ViewThemeModel a = await theme.CreateTheme(themesModel);
            return Ok(a);
        }
        [HttpPut]
        [Route("UpdateTheme")]
        public async Task<IActionResult> UpdateTheme(int theme_Id, ViewThemeModel themesModel)
        {
            _logger.LogInformation("Theme Updated Successfully");
            ViewThemeModel a = await theme.UpdateTheme(theme_Id, themesModel);
            return Ok(a);
        }
        [HttpDelete]
        [Route("DeleteTheme")]
        public async Task<IActionResult> DeleteTheme(int theme_Id)
        {
            _logger.LogInformation("Theme Deleted Successfully");
            ViewThemeModel a = await theme.DeleteTheme(theme_Id);
            return Ok(a);
        }
        
        [HttpGet("GetThemesByThemeID")]
        public async Task<IActionResult> GetThemesByThemeID(int theme_Id)
        {
            _logger.LogInformation("GetThemesByThemeID Successfully");
            var pt = await theme.GetThemesByThemeID(theme_Id);
            if (pt != null)
            {
                return Ok(pt);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpGet]
        [Route("GetAllThemes")]
        public async Task<IActionResult> GetAllThemes()
        {
            _logger.LogInformation("GetAllThemes Successfully");
            var a = await theme.GetAllThemes();
            return Ok(a);
        }

        [HttpGet]
        [Route("GetAllThemesDescending")]
        public async Task<IActionResult> GetAllThemesInDescending()
        {
            _logger.LogInformation("GetAllThemes in Descending Successfully");
            var a = await theme.GetThemeDescending();
            return Ok(a);
        }


    }
}
