﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MutualFund.Models;
using MutualFund.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class AssetClassesController : ControllerBase
    {
        private readonly IAssetClass asset = null;
        public AssetClassesController(IAssetClass asset)
        {
            //this.dbContext = dbContext;
            this.asset = asset;
        }
        [HttpPost]
        [Route("CreateAssetClass")]
        public async Task<IActionResult> CreateAssetClass(AssetClassesModel assetClassesModel)
        {
            var a = await asset.CreateAssetClass(assetClassesModel);
            return Ok(a);
        }
        [HttpPut]
        [Route("UpdateAssetClass")]
        public async Task<IActionResult> UpdateAssetClass(int asset_ID, AssetClassesModel assetClassesModel)
        {
            var a = await asset.UpdateAssetClass(asset_ID, assetClassesModel);
            return Ok(a);
        }
        [HttpDelete]
        [Route("DeleteAssetClass")]
        public async Task<IActionResult> DeleteAssetClass(int asset_ID)
        {
            var a = await asset.DeleteAssetClass(asset_ID);
            return Ok(a);
        }

        [HttpGet]
        [Route("GetAssetsByID)")]
        public async Task<IActionResult> GetAssetclassByID(int asset_ID)
        {
            var pt = await asset.GetAssetClassByID(asset_ID);
            if (pt != null)
            {
                return Ok(pt);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpGet]
        [Route("GetAllAssetClasses")]
        public async Task<IActionResult> GetAllAssetClasses()
        {
            var a = await asset.GetAllAssetClasses();
            return Ok(a);
        }
    }
}
