﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MutualFund.DI;
using MutualFund.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MutualFund.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class PortfolioHeaderController : ControllerBase
    {
        private readonly IPortfolioHeader header = null;
        private readonly ILogger<PortfolioHeaderController> _logger;
        public PortfolioHeaderController(IPortfolioHeader header,ILogger<PortfolioHeaderController> logger)
        {
            _logger = logger;
            this.header = header;
        }
        [HttpPost]
        [Route("CreateHeader")]
        public async Task<IActionResult> CreateHeader([FromBody] PortfolioHeaderModel portfolioHeaderModel)
        {
            _logger.LogInformation("Header is Created Successfully");
            PortfolioHeaderModel a = await header.CreateHeader(portfolioHeaderModel);
            return Ok(a);
        }
        [HttpPut]
        [Route("UpdateHeader")]
        public async Task<IActionResult> UpdateHeader(int portfolio_ID, PortfolioHeaderModel portfolioHeaderModel)
        {
            _logger.LogInformation("Header Updated Successfully");
            PortfolioHeaderModel a = await header.UpdateHeader(portfolio_ID, portfolioHeaderModel);
            return Ok(a);
        }
        [HttpDelete]
        [Route("DeleteHeader")]
        public async Task<IActionResult> DeleteHeader(int portfolio_ID)
        {
            _logger.LogInformation("Header Deleted Successfully");
            PortfolioHeaderModel a = await header.DeleteHeader(portfolio_ID);
            return Ok(a);
        }
        //[HttpPost("Userlogin")]
        //public async Task<IActionResult> Login(PortfolioHeaderModel portfolioHeaderModeldel)
        //{
        //    PortfolioHeaderModel ar = await header.Login(portfolioHeaderModeldel);
        //    return Ok(ar);

        //}
        [HttpGet("GetPortfolioHeaderByName/{name_of_the_portfolio}")]
        public async Task<IActionResult> GetPortfolioHeaderByName(string name_of_the_portfolio)
        {
            _logger.LogInformation("GerPortfolioHeaderByName Successfully");
            var pt = await header.GetPortfolioHeaderByName(name_of_the_portfolio);
            if (pt != null)
            {
                return Ok(pt);
            }
            else
            {
                return NotFound();
          
            }
        }
        //[HttpGet]
        //public async Task<IActionResult> GetPortfolioHeaderByThemeId(int Theme_id)
        //{
        //    var pt = await header.GetPortfolioHeaderByThemeId(Theme_id);
        //    if (pt != null)
        //    {
        //        return Ok(pt);
        //    }
        //    else
        //    {
        //        return NotFound();
        //    }
        //}
        //[HttpGet("Forgotpassword")]
        //public async Task<IActionResult> ForgotPassword(string email)
        //{
        //    var res = await header.ForgotPassword(email);
        //    return Ok(res);
        //}
        [HttpGet]
        [Route("GetAllPortfolioHeader")]
        public async Task<IActionResult> GetAllPortfolioHeader()
        {
            _logger.LogInformation("GetAllPortfolioHeader Successfully");
            var a = await header.GetAllPortfolioHeader();
            return Ok(a);
        }
        [HttpGet]
        [Route("GetById")]
        public async Task<IActionResult> GetPortfolioHeaderById(int portfolio_Id)
        {
            _logger.LogInformation("GerPortfolioHeaderById Successfully");
            var a = await header.GetPortfolioHeaderById(portfolio_Id);
            return Ok(a);
        }
    }
    


}
